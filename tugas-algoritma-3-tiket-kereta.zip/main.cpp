/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int kode, jumlah;
    int diskon, total;
    
    int I = 100.000;
    int J = 200.000;
    int K = 300.000;
    
    string tiket;
    
    
    cout << endl;
    cout << "=================================================" <<endl;
    cout << "      DAFTAR HARGA DAN KELAS TIKET KERETA        " <<endl;
    cout << "=================================================" <<endl<< endl;
    cout << " (kode : 1) = Kelas Ekonomi           Rp. 100000 " <<endl;
    cout << " (kode : 2) = Kelas Bisnis            Rp. 200000 " <<endl;
    cout << " (kode : 3) = Kelas Eksekutif         Rp. 300000 " <<endl;
    cout << endl;
    cout << "=================================================" <<endl;
    
    cout << "  masukan kode kereta : ";
    cin >> kode;
    cout << endl;
    
    cout << "  masukan jumlah tiket : ";
    cin >> jumlah;
    cout << endl;
    
    cout << " Berikut adalah rincian pembayaran : " << endl;
    cout << "=========================================" <<endl;

    switch(kode){
        case 1 :
        tiket = "Ekonomi";
        total += I * jumlah;
        break;
        
        case 2 :
        tiket = "Bisnis";
        total += J * jumlah;
        break;
        
        case 3 :
        tiket = "Eksekutif";
        total += K * jumlah;
        break;
    }
        cout << endl;
          cout << "   anda memesan " << jumlah << " tiket tersebut " << tiket << " dengan total harga " << total << " ribu " << endl;
          cout << endl;
        if (total >= 500.000){
            diskon = total * 90 / 100;
        cout << "   kamu mendapatkan diskon 10 % kamu hanya perlu membayar dengan total " << diskon << " ribu " << endl<<endl;
        }
    else if (total >= 300000){
            diskon = total * 95 / 100;
            cout << " kamu mendapatkan diskon 5 % kamu hanya perlu membayar dengan total " << diskon;
    }
    else if (total >= 200000){
            diskon = total * 98 / 100;
            cout << " kamu mendapatkan diskon 5 % kamu hanya perlu membayar dengan total " << diskon;
    }
        cout << "=================================================" <<endl;
        cout << "     Terima Kasih atas pembelian tiket nya :)    " <<endl;
        cout << "     selamat berlibur dan hati hati di jalan     " <<endl;
        cout << "=================================================" <<endl;
    
    
    return 0;
}



